# Code in the package

This directory contains source code or build artifacts.
Importers MUST NOT install or execute these files automatically.
