# content.format Registry

| format | data type | description |
| --- | --- | --- |
| `html` | string | HTML string. |
| `markdown` | string | Markdown text. |
| `editorjs` | object | Editor.js object. |
| `blocks-v1` | object | Structured blocks v1. |
| `text` | string | Plain text. |
